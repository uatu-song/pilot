# CHARACTER STATE: [NAME]

**As Of:** Chapter [X]
**Last Updated:** [Date]

---

## LOCATION

**Current:** [Where they are]
**With:** [Who they're with]
**Heading:** [Where they're going]

---

## PHYSICAL CONDITION

| Aspect | Status |
|--------|--------|
| Overall | [Critical / Injured / Stable / Healthy] |
| Specific | |

**Inventory:**
-
-

---

## KNOWLEDGE STATE

### Knows Now:
-
-

### Learned This Chapter:
-

### Still Doesn't Know:
-
-

---

## ARC POSITION

**Current Beat:** [Where in their arc]
**Last Key Moment:** [What just happened]
**Next Tension:** [What's coming]

---

## CHAPTER LOG

| Ch | Location | Key Event | State Change |
|----|----------|-----------|--------------|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |

---

*Updated after each chapter*
